<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <img src="assets/img/footer-logo.png    " alt="HPIT">
            </div>
            <div class="col-md-3">
                <ul>
                    <li>
                        <a href="#">Company</a>
                    </li>
                    <li>
                        <a href="#">Capabilities</a>
                    </li>
                    <li>
                        <a href="#">Careers</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <ul>
                    <li>
                        <a href="#">Insights</a>
                    </li>
                    <li>
                        <a href="#">Industries</a>
                    </li>
                    <li>
                        <a href="#">About HPIT</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3">
                <h3>Have A Question</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit, sed do eiusmod tempor incididunt ut labore et
                    dolore magna aliqua. </p>
                <a href="#" class="blueBtn">Form Fill</a>
            </div>
        </div>
    </div>
</footer>
<div class="subFooter">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <p class="copyright">©2024HPIT</p>
            </div>
            <div class="col-md-8">
                <ul class="">
                    <li>
                        <a href="#">EEO</a>
                    </li>
                    <li>
                        <a href="#">Privacy</a>
                    </li>
                    <li>
                        <a href="#">Cookies</a>
                    </li>
                    <li>
                        <a href="#">Employess</a>
                    </li>
                    <li>
                        <a href="#">Team</a>
                    </li>
                    <li>
                        <a href="#">Suppliers</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>